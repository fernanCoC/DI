import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

public class Evento {
    private String ubicacion;
    private  int id;

    public Evento() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    private Date fechaEvento;
    private ArrayList<Personas>listaPersonas;
    private boolean reprogramado;
    Personas personas;

    public void reprogramar(Date nuevaFecha){
        if(reprogramado && nuevaFecha.before(this.fechaEvento)){
            System.out.println("Cambiando fecha...");
        }
        this.fechaEvento=nuevaFecha;
        reprogramado=true;
    }
    /*public void agregarAsistente(String nombre){
        if (!listaPersonas.contains(nombre)){
            listaPersonas.add(nombre);
            System.out.println("Agregado correctamente");
        }else {
            System.out.println("No se pudo agregar asistente");
        }
    }*/

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public Date getFechaEvento() {
        return fechaEvento;
    }

    public void setFechaEvento(Date fechaEvento) {
        this.fechaEvento = fechaEvento;
    }

    public ArrayList<Personas> getListaPersonas() {
        return personas.getListaPersonas();
    }

    public void setListaPersonas(ArrayList<Personas> listaPersonas) {
        this.listaPersonas = listaPersonas;
    }

    public boolean isReprogramado() {
        return reprogramado;
    }

    public void setReprogramado(boolean reprogramado) {
        this.reprogramado = reprogramado;
    }

    public Evento(String ubicacion, int id, Date fechaEvento, ArrayList<Personas> listaPersonas, boolean reprogramado) {
        this.ubicacion = ubicacion;
        this.id = id;
        this.fechaEvento = fechaEvento;
        this.listaPersonas = new ArrayList<>();
        this.reprogramado = reprogramado;
    }
}
