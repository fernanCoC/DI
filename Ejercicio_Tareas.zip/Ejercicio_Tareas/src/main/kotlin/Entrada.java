public class Entrada {
    public static void main(String[] args) {
        Gestor gestor=new Gestor();
        gestor.mostrarMenu();
    }
}
