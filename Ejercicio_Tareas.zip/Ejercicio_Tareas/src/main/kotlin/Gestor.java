import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Gestor {
    Scanner scanner = new Scanner(System.in);

    ArrayList<Tareas> listadeTareas = new ArrayList<>();
    ArrayList<Reuniones> listadeReuniones = new ArrayList<>();
    ArrayList<Personas> listaAsistentes = new ArrayList<>();
    Evento evento;
    Personas personas;

    //Reuniones reuniones = new Reuniones();


    public void mostrarMenu() {
        while (true) {
            System.out.println("\nMenu Principal");
            System.out.println("1.  Agregar tarea o una reunion");
            System.out.println("2.  Borrar tarea");
            System.out.println("3.  Actualizar tarea");
            System.out.println("4.  Listar tarea");
            System.out.println("5.  Agregar asistente a reunion");
            System.out.println("6.  Reprogramar evento o reunion");
            System.out.println("7.  Buscar asistente");
            System.out.println("8.  Ver programadas");
            System.out.println("9.  Salir");

            int option = scanner.nextInt();
            scanner.nextLine();

            switch (option) {
                case 1:
                    agregarTareaReunion();
                    break;
                case 2:
                    borrarTarea();
                    break;
                case 3:
                    actualizarTarea();
                    break;
                case 4:
                    listarTareas();
                    break;
                case 5:
                    agregarAsistente();
                    break;
                case 6:
                     reprogrmarEvento();
                    break;
                case 7:
                    buscarAsistente();
                    break;
                case 8:
                    verProgramas();
                    break;
                case 9:
                    System.out.println("Saliendo del sistema");
                    break;
                default:
                    System.out.println("La opcion no esta contemplada en el menu " +
                            "por favor vuelva a introducir un numero valido ");

            }
        }
    }

    public void verProgramas() {
        boolean hayReprogramados = false;
        for (Reuniones item : listadeReuniones) {

            if (evento.isReprogramado()) {
                System.out.println("ID de la reunion"+item.getId());

                System.out.println("Nueva fecha de la reunion"+item.getFechaReunion());
                hayReprogramados = true;
            }
        }
        if (!hayReprogramados){
            System.out.println("No se encuntra ninguna reunion");
        }

    }

    public void reprogrmarEvento() {
        System.out.println("Ingrese id de la reunion");
        int idEvento = scanner.nextInt();

        for (Reuniones evento : listadeReuniones) {
            if (evento.getId() == idEvento) {
                if (evento.getId() == idEvento) {
                    System.out.println("Ingrese la nueva fecha");
                    String nuevaFecha = scanner.next();

                    try {
                        Date fechaRepro = new SimpleDateFormat("yyyy-MM-dd").parse(nuevaFecha);
                        evento.setFechaReunion(fechaRepro);
                        evento.setReprogramado(true);

                        System.out.println("La fecha del evento ha sido reprogramada");
                    } catch (Exception e) {
                        System.out.println("Introduce bien la fecha");
                    }
                    return;
                }

            }
        }

    }

    public void buscarAsistente() {
        System.out.println("Ingrese el nombre del asistente que quieres buscar");
        String nombreBuscqueda = scanner.nextLine();
        boolean encontrado = false;

        for (Reuniones reuniones:listadeReuniones){
            for (Personas personas:reuniones.getListaInvitados()){
                if (personas.getNombre().equalsIgnoreCase(nombreBuscqueda)){
                    System.out.println("Asistente encontrado...");
                    System.out.println("ID"+reuniones.getId());
                    System.out.println("Fecha: "+reuniones.getFechaReunion());
                }
            }
        }


        if (!encontrado) {
            System.out.println("No se encontro ningun evento");
        }


    }

    public void buscarTarea() {
        System.out.println("Ingrese el id de la tarea que desea buscar");
        int id = scanner.nextInt();
        for (Tareas item : listadeTareas) {
            if (id != 0 && item.getId() == id) {
                System.out.println("Tarea encontrada");
                System.out.println("Titulo" + item.getTitulo());
                System.out.println("Descripcion" + item.getDescripcion());

            }

        }

    }




    public void agregarAsistente() {
        System.out.println("Ingrese ID de la ruinion que quieres agregar un invitado");
        int idReunion=Integer.parseInt(scanner.nextLine());

        for (Reuniones reuniones:listadeReuniones) {
            if (reuniones.getId()==idReunion){
                System.out.println("La reunion fue encontrada:"+reuniones.getId());

                System.out.println("Ingresa ID de la persona");
                int idPersona=scanner.nextInt();

                System.out.println("Ingrese su nombre");
                String nombrePersona=scanner.next();

                System.out.println("Ingresa apellido");
                String apellidoPersona= scanner.next();

                Personas personas1=new Personas(nombrePersona,apellidoPersona,idPersona);

                reuniones.agregarAsistente(personas1);

                System.out.println("Asistente"+nombrePersona+" agregado correctamente");
            }

        }
        System.out.println("No se encontro la reunion");
    }

    public void borrarTarea() {
        if (listadeTareas.isEmpty()) {
            System.out.println("la lista esta vacia");

        }
        System.out.println("Ingrese id");
        int id = scanner.nextInt();

        if (id > 0 && id < listadeTareas.size()) {
            Tareas tareas = listadeTareas.remove(id);
            System.out.println("Tarea " + tareas.getTitulo() + "fue borrada correctamente");
        } else {
            System.out.println("La tarea no se pudo borrar");
        }
    }

    public void actualizarTarea() {
        System.out.println("Ingrese el ID de la tarea que desea actualizar");
        int id=Integer.parseInt(scanner.nextLine());

        for (Tareas item:listadeTareas){
            if (item.getId()==id){
                System.out.println("Ingrese nuevo titulo");
                String tituloNuevo=scanner.nextLine();
                if (!tituloNuevo.isEmpty()){
                    item.setTitulo(tituloNuevo);
                }
            }
            System.out.println("Ingrese nueva prioridad");
            String prioridadNueva=scanner.nextLine();
            if (!prioridadNueva.isEmpty()){
                boolean nuevaPrioridad=prioridadNueva.equalsIgnoreCase("si");
                item.setPrioridad(nuevaPrioridad);
            }
            System.out.println("La tarea se actualizo");
            return;
        }

    }

    public void listarTareas() {
        System.out.println("Leyendo...");
        for (Tareas tareas:listadeTareas){
            System.out.println("ID: "+tareas.getId());
            System.out.println("Titulo: "+tareas.getTitulo());
            System.out.println("Descripcion: "+tareas.getDescripcion());
            System.out.println("Prioridad: "+(tareas.isPrioridad()?"Si":"No"));
            System.out.println("Completado: "+(tareas.isCompletada()?"Si":"No"));
        }

    }

    public void agregarTareaReunion() {

        System.out.println("Selecciona el tipo de tarea o reunion que deseas agregar");
        System.out.println("1. Tarea Sencilla");
        System.out.println("2. Tarea Programable");
        System.out.println("3. Reunion");
        int opciones = 0;
        try {
            opciones = scanner.nextInt();

        } catch (Exception e) {
            System.out.println("Opcion no concreta");
        }

        switch (opciones) {
            case 1:
                agregarTareaSencilla();
                break;
            case 2:
                agregarTareaProgramable();
                break;
            case 3:
                agregarReunion();
                break;
            default:
                System.out.println("Opcion no contemplada");


        }

    }

    public void agregarTareaSencilla() {

        System.out.println("Ingrese id");
        int id = scanner.nextInt();

        System.out.println("Ingrese titulo");
        String titulo = scanner.next();

        System.out.println("Ingrese descripcion");
        String descripcion = scanner.next();

        System.out.println("Ingrese Prioridad");
        boolean prioridad=scanner.nextBoolean();


        System.out.println("Ingrese completado");
        boolean completado = scanner.nextBoolean();

        TareaSencilla tareaSencilla = new TareaSencilla(id, titulo, descripcion, prioridad, completado);
        listadeTareas.add(tareaSencilla);

        System.out.println("Se ha agregado correctamente");
    }

    public void agregarTareaProgramable() {

        System.out.println("Ingrese id");
        int id = scanner.nextInt();

        System.out.println("Ingrese titulo");
        String titulo = scanner.next();

        System.out.println("Ingrese descripcion");
        String descripcion = scanner.next();

        System.out.println("Ingrese Prioridad");
        boolean prioridad = scanner.nextBoolean();

        System.out.println("Ingrese completado");
        boolean completado = scanner.nextBoolean();

        System.out.println("Ingrese la fecha de la tarea");
        LocalDate fechaTR = null;
        try {
            fechaTR = LocalDate.parse(scanner.nextLine());
        } catch (Exception e) {
            System.out.println("Formato de la fecha incorrecto");
        }
        System.out.println("Ingrese resultado");
        String resultado = scanner.next();

        TareaProgramable tareaProgramable = new TareaProgramable(id, titulo, descripcion, prioridad, completado, fechaTR, resultado);
        listadeTareas.add(tareaProgramable);


    }

    public void agregarReunion() {


        /*System.out.println("Ingrese fecha");
        LocalDate fecha= LocalDate.parse(scanner.next());
        try {
            fecha = LocalDate.now();
        } catch (Exception e) {
            System.out.println("Fecha incorrecta");
        }*/

        System.out.println("Ingresa importancia");
        boolean importancia = scanner.nextBoolean();

        System.out.println("Ingrese id");
        int id = scanner.nextInt();

        Reuniones reuniones=new Reuniones(importancia,id);
        listadeReuniones.add(reuniones);
    }
}

