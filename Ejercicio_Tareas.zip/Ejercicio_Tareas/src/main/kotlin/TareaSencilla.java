public class TareaSencilla extends Tareas{
    public TareaSencilla(int id, String titulo, String descripcion, boolean prioridad, boolean completada) {
        super(id, titulo, descripcion, prioridad, completada);
    }
}
