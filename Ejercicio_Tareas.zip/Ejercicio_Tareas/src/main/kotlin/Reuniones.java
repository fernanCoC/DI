import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

public class Reuniones {
    private Date fechaReunion;
    private boolean importante,reprogramado;
    private int id;
    private ArrayList<Personas>listaInvitados=new ArrayList<>();

    public ArrayList<Personas> getListaInvitados() {
        return listaInvitados;
    }

    public void setListaInvitados(ArrayList<Personas> listaInvitados) {
        this.listaInvitados = listaInvitados;
    }

    public void agregarAsistente(Personas asistente) {
        this.listaInvitados.add(asistente);
    }

    public Reuniones(boolean importante, int id) {
        this.importante = importante;

        this.id = id;
    }

    public void reprogramarReunion(Date nuevaReunion, boolean reunionImportante){
        if (reprogramado && fechaReunion.before(nuevaReunion)){
            System.out.println("Cambiando la fecha...");

        }
        fechaReunion = nuevaReunion;
        reprogramado = true;
        if (importante =true){
            System.out.println("La reunion esta marcada como importante");
        }else {
            System.out.println("Su renion no es importante");
        }


    }

    public Reuniones(Date fechaReunion, boolean importante, boolean reprogramado, int id, ArrayList<Personas> listaInvitados) {
        this.fechaReunion = fechaReunion;
        this.importante = importante;
        this.reprogramado = reprogramado;
        this.id = id;
        this.listaInvitados = new ArrayList<>();
    }



    public Reuniones() {
    }

    public Date getFechaReunion() {
        return fechaReunion;
    }

    public void setFechaReunion(Date fechaReunion) {
        this.fechaReunion = fechaReunion;
    }

    public boolean isImportante() {
        return importante;
    }

    public void setImportante(boolean importante) {
        this.importante = importante;
    }

    public boolean isReprogramado() {
        return reprogramado;
    }

    public void setReprogramado(boolean reprogramado) {
        this.reprogramado = reprogramado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
