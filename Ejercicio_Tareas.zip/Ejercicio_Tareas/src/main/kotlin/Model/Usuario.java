package Model;

public class Usuario {
}
