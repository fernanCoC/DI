package Model;

public class UsuarioMaster {
}
