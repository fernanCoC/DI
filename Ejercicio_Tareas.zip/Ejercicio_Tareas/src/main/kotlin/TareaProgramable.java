import java.time.LocalDate;

public class TareaProgramable extends Tareas{
    private LocalDate fecha;
    private String resultado;

    public TareaProgramable(int id, String titulo, String descripcion, boolean prioridad, boolean completada, LocalDate fecha, String resultado) {
        super(id, titulo, descripcion, prioridad, completada);
        this.fecha = fecha;
        this.resultado = resultado;
    }

    public TareaProgramable(int id, String titulo, String descripcion, boolean prioridad, boolean completada) {
        super(id, titulo, descripcion, prioridad, completada);

    }
}
